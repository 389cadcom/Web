var path = require('path');						//处理目录对象
var webpack = require('webpack');

module.exports = [
    entry: './src/main.js',
    output: {
        path: path.join(__dirname, './dist'),
        publicPath: '/dist/',
        filename: '[name].js'
    },
    module: {
        loaders: [
	        { test: /\.css$/, loader: 'style!css!autoprefixer' }, 
	        { test: /\.sass$/, loader: 'style!css!sass?sourceMap' }, 
	        { test: /\.js$/, loader: 'babel', exclude: /node_modules/ }, 
	        { test: /\.json$/, loader: 'json' }, 
	        
	        { test: /\.vue$/, loader: 'vue' }, 
	        { test: /\.html$/, loader: 'vue-html' }, 
	        { test: /\.(png|jpg|gif|svg)$/, loader: 'url', 
	          	query: { limit: 8192, name: '[name].[ext]?[hash]' }
	        }
        ]
    },
    resolve: {
    	// require时省略的扩展名
    	extensions: ['', '.css', '.scss', '.js', '.vue'],
    	// 别名
    	alias: {
    		components: path.join(__dirname, '/src/components/')
    	}
    },
    plugins: [
    	
    ],
	externals: {
		vue: "Vue"
	},
	// 开启source-map
    //devtool: 'cheap-module-source-map',
    
	//转换ES6语法
	babel: {
		presets: ['es2015'],
		plugins: ['transform-runtime']
	},
	//服务器配置相关，自动刷新!
  	devServer: {
        historyApiFallback: true,
        hot: false,
        inline: true,
        grogress: true,
        noInfo: true
    }
}
