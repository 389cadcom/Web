<template>
	<div class=""><a href="#">组件内容可以更新，主页的HTML不能更新!!!</a></div>
	<p>{{ message }}</p>
</template>

<script>
export default {
	data: function(){
		return {message: 'App Template Test'}
	}
}
</script>
<style lang="sass">
$color: rgba(255,0,0,0.5);
@keyframes opacity{
	from{opacity: 1;}
	to{ opacity: 0;}
};
body {
	background: $color;
	font-size: 14px;
	font-family: "helvetica, arial, sans-serif";
	box-sizing: border-box;
}
a{
	text-decoration: none;
	color: #a00;
	transform: translate(10%, 10%);/*测试自动添加前缀*/
	&:hover{
		color: #f60;
		text-decoration: underline;
	}
}
</style>
