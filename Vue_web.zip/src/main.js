//var Vue = require('vue');
import Vue from 'vue'
import App from './components/App'

new Vue({
  el: 'body',
  data: {
  	message: 'Demo test'
  },
  components: { App }
})


/*new Vue({
	el: 'body',
	data: {
		message: 'hello'
	}
})
*/